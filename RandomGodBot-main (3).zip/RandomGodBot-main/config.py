TOKEN = ''
db_url = ''
channel = ''
